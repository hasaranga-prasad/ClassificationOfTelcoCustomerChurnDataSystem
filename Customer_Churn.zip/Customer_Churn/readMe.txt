TELCO CUSTOMER CHURN PREDICTOR
Run model application
1.	open cmd(path Customer_Churn\model)
2.	create virtual environment 
�	pip install virtualenv
�	virtualenv env
3.	install libraries
4.	pip install numpy
5.	pip install scikit-learn
6.	activate environment (activate)
7.	goto model folder
�	cd ../ ../
�	pip install jupyter
�	open jupyter
�	jupyter notebook

Run web application
              
1.	open cmd(path Customer_Churn\ web)
2.	install libraries(create virtual environment)
a.	pip install numpy
b.	pip install flask
c.	pip install sckit-learn
d.	activate environment (activate)
e.	goto model folder(cd ../ ../)
3.	open vscord
4.	open terminal
5.	run python app
6.	python app.py






check samples
0= no;
1=yes;
SeniorCitizen, Partner, Dependents, tenure, PhoneService, MultipleLines, InternetService, OnlineSecurity, OnlineBackup, DeviceProtection, TechSupport, StreamingTV, StreamingMovies, PaperlessBilling, MonthlyCharges, TotalCharges, Male, MM, OY, TY, Bank, Card, Check
0,0,0,2,1,0,1,1,1,0,0,0,0,1,436,536,male,mm,check
0,0,0,2,1,0,1,0,0,0,0,0,0,1,729,674,female,mm,check
0,0,0,8,1,1,1,0,0,1,0,1,1,1,1274,2173,female,mm,check
0,0,1,22,1,1,10,1,0,0,1,0,1,1075,3673,male,oy,card
0,0,0,10,0,0,1,1,0,0,0,0,0,0,140,1145,female,ty,check