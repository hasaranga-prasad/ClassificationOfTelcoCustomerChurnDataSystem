from flask import Flask, render_template, request
import pickle
import numpy as np
app = Flask(__name__)
def prediction(lst):
    filename ='model/predictor.pickle'
    with open(filename,'rb') as file:
        model = pickle.load(file)
    pred_value = model.predict([lst])
    return pred_value
@app.route('/',methods=['POST','GET'])
def index():
    pred ="please enter deteils"
    if request.method =='POST':
        seniorCitizen = request.form['seniorCitizen']
        partner = request.form['partner']
        dependents = request.form['dependents']
        tenure = request.form['tenure']
        phoneService = request.form['phoneService']
        multipleLines = request.form['multipleLines']
        internetService = request.form['internetService']
        onlineSecurity = request.form['onlineSecurity']
        onlineBackup = request.form['onlineBackup']
        deviceProtection = request.form['deviceProtection']
        techSupport = request.form['techSupport']
        streamingTv = request.form['streamingTv']
        streamingMovies = request.form['streamingMovies']
        paperlessBilling = request.form['paperlessBilling']
        monthlyCharges = request.form['monthlyCharges']
        totalCharges = request.form['totalCharges']
        gender = request.form['gender']
        contract = request.form['contract']
        paymentMethod = request.form['paymentMethod']
        
        print(seniorCitizen,partner,dependents,tenure,phoneService,multipleLines,deviceProtection,internetService,onlineSecurity,onlineBackup
              ,techSupport,streamingTv,streamingMovies,paperlessBilling,monthlyCharges,totalCharges,gender,contract,paymentMethod)
          
        def select (item):
         if (item == 'yes'):
            return feature_list.append(1)
         else:
           return feature_list.append(0)
        def select3 (item):
             if (item == 'yes'):
                return feature_list.append(1)
             else:
                return feature_list.append(0)
            
        def select1 (item):
             if (item == 'yes'):
              return feature_list.append(1)
             elif(item == 'no'):
              return feature_list.append(0)
             elif(item == 'nos'):
              return feature_list.append(0)
          
        def select2 (item):
             if (item == 'dsl'):
              return feature_list.append(1)
             elif(item == 'fiber_optic'):
              return feature_list.append(1)
             elif(item == 'no'):
              return feature_list.append(0)
        
        feature_list = []
        select(seniorCitizen)   
        select(partner) 
        select(dependents)
        feature_list.append(int(tenure))
        select(phoneService)
        select1(multipleLines)
        select2(internetService)
        select1(onlineSecurity)
        select1(onlineBackup)
        select1(deviceProtection)
        select1(techSupport)
        select1(streamingTv)
        select1(streamingMovies)
        select(paperlessBilling)
        feature_list.append(float(monthlyCharges))
        feature_list.append(float(totalCharges))
        select3(gender)
        contract_list=['mm','oy','ty']
        paymentMethod_list=['bank','card','check']
        
        for item1 in contract_list:
            if item1 == contract:
                feature_list.append(1)
            else:
                feature_list.append(0)        
        for item2 in paymentMethod_list:
            if item2 ==paymentMethod :
                feature_list.append(1)
            else:
                feature_list.append(0)
                
        print(feature_list)
        
        pred = prediction(feature_list)
        print(pred)
        
        pred = np.round(pred[0])
        
        
        
        
       
        
       
    return render_template("index.html", pred = pred)


if __name__=='__main__':
    app.run(debug=True)